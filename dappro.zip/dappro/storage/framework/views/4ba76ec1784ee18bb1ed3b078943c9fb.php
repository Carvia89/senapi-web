<?php $__env->startSection('content'); ?>
<main id="main" class="main">

    <div class="pagetitle">
      <h1>Liste</h1>
      <nav class="d-flex justify-content-between align-items-center">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
          <li class="breadcrumb-item">Directions</li>
          <li class="breadcrumb-item active">Liste</li>
        </ol>
        <a type="text" class="btn btn-primary" href="<?php echo e(route('admin.direction.create')); ?>">Ajouter</a>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
          <div class="col-lg-12">

            <?php if(Session('success')): ?>
            <div class="alert alert-success d-flex align-items-center">
                <i class="bi bi-hand-thumbs-up-fill me-2"></i>
                <span><?php echo e(session('success')); ?></span>
            </div>
            <?php endif; ?>

            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Liste des Directions</h5>

                <table class="table table-hover">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Désignation</th>
                        <th scope="col" class="text-end">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($direction->id); ?></td>
                                <td><?php echo e($direction->designation); ?></td>
                                <td>
                                    <div class="d-flex gap-2 w-100 justify-content-end">
                                        <a href="<?php echo e(route('admin.direction.edit', $direction->id)); ?>" title="Editer" class="btn btn-primary"><i class="bi bi-pencil color-muted m-r-5"></i></a>
                                        <form action="<?php echo e(route('admin.direction.destroy', $direction->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("delete"); ?>
                                            <button class="btn btn-danger" title="Supprimer">
                                                <i class="bi bi-trash-fill color-muted m-r-5"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  <!-- End Table with hoverable rows -->

             <!-- Pagination with icons -->
                  <?php echo e($directions->links()); ?>


              </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
          &copy; Copyright <strong><span>DANTIC-SENAPI</span></strong>. All Rights Reserved
        </div>
    </footer><!-- End Footer -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thambafr/dappro-senapi.thambafreelance.com/dappro/resources/views/admin/directions/index.blade.php ENDPATH**/ ?>